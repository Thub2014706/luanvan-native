import { Alert, ScrollView, StyleSheet, Text, TouchableWithoutFeedback, View } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useLocalSearchParams } from 'expo-router';
import { detailShowTimeById } from '~/services/ShowTimeService';
import { detailRoom } from '~/services/RoomService';
import { allSeatRoom } from '~/services/SeatService';
import { signAge, standardAge, typeSeatEnum, typeUserPrice, WIDTH } from '~/constants';
import BackIcon from '~/components/BackIcon/BackIcon';
import { detailFilmBySchedule } from '~/services/FilmService';
import { detailPriceByUser } from '~/services/PriceService';
import ImageBase from '~/components/ImageBase/ImageBase';
import Ionicons from '@expo/vector-icons/Ionicons';
import { detailTheater } from '~/services/TheaterService';
import { allOrderTicketSelled } from '~/services/OrderTicketService';
import { allHold } from '~/services/RedisService';
import moment from 'moment';
import { Image } from 'expo-image';

const Seat = () => {
    const { id } = useLocalSearchParams<{ id: string }>();
    const [seats, setSeats] = useState([]);
    const [selectSeat, setSelectSeat] = useState([]);
    const [selled, setSelled] = useState([]);
    const [hold, setHold] = useState([]);
    const [showTime, setShowTime] = useState();
    const [room, setRoom] = useState();
    const [theater, setTheater] = useState();
    const [film, setFilm] = useState();
    const [priceSeat, setPriceSeat] = useState(0);

    useEffect(() => {
        const fetch = async () => {
            const showTime = await detailShowTimeById(id);
            const roomData = await detailRoom(showTime.room);
            const filmData = await detailFilmBySchedule(showTime.schedule);
            const theaterData = await detailTheater(showTime.theater);
            const data = await allSeatRoom(showTime.room);
            setShowTime(showTime);
            setSeats(data);
            setRoom(roomData);
            setFilm(filmData);
            setTheater(theaterData);
        };
        fetch();
    }, [id]);

    useEffect(() => {
        const fetch = async () => {
            if (id) {
                const data = await allOrderTicketSelled(id);
                setSelled(data);
            }
        };
        fetch();
    }, [id]);

    const rows = [...new Set(seats.map((item) => item.row))];

    const handleSelectSeat = async (seat) => {
        if (!selectSeat.includes(seat)) {
            const seatArray = [...selectSeat, seat];
            const allSameType = seatArray.every((item) => item.type === seatArray[0].type);

            if (!allSameType) {
                Alert.alert('Lỗi chọn ghế', 'Hãy chọn ghế cùng loại!', [
                    { text: 'Đóng', onPress: () => console.log('OK Pressed') },
                ]);
            } else {
                setSelectSeat(seatArray);
            }
        } else {
            setSelectSeat(selectSeat.filter((item) => item !== seat));
        }
    };

    const handleSelectSeatCouple = (seat) => {
        const arrayRow = seats.filter((item) => item.row === seat.row);
        const seatIndex = arrayRow.indexOf(seat);
        const nextChair = arrayRow[seatIndex].col % 2 === 0 ? arrayRow[seatIndex - 1] : arrayRow[seatIndex + 1];

        if (!selectSeat.includes(seat && nextChair)) {
            const seatArray = [...selectSeat, seat, nextChair];
            // console.log(seatArray);
            const allSameType = seatArray.every((item) => item.type === seatArray[0].type);

            if (!allSameType) {
                Alert.alert('Lỗi chọn ghế', 'Hãy chọn ghế cùng loại!', [
                    { text: 'Đóng', onPress: () => console.log('OK Pressed') },
                ]);
            } else {
                setSelectSeat(seatArray);
            }
        } else {
            setSelectSeat(selectSeat.filter((item) => item !== seat && item !== nextChair));
        }
    };

    useEffect(() => {
        const handleNavigation = async () => {
            const data = await allHold(id);
            setHold(Object.keys(data));
        };

        handleNavigation();
    }, [id]);

    useEffect(() => {
        const fetch = async () => {
            if (selectSeat.length > 0) {
                let data = await Promise.all(
                    selectSeat.map(
                        async (item) =>
                            await detailPriceByUser(
                                typeUserPrice[3],
                                showTime.date,
                                showTime.timeStart,
                                room._id,
                                item._id,
                            ),
                    ),
                );
                const sum = data.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
                setPriceSeat(sum);
            } else {
                setPriceSeat(0);
            }
        };
        fetch();
    }, [selectSeat, room, showTime]);
    // console.log(selectSeat);

    return film && theater ? (
        <>
            <BackIcon />
            <ScrollView>
                <View style={styles.container}>
                    <View style={styles.containerInfo}>
                        <ImageBase pathImg={film.image} style={{ width: 70, height: 100 }} />
                        <View style={styles.contentMain}>
                            <Text style={{ fontWeight: '500', marginBottom: 5, marginEnd: 10 }}>
                                {film.name} [{signAge[standardAge.findIndex((mini) => mini === film.age)]}]
                            </Text>
                            <View style={{ flexDirection: 'row', gap: 2 }}>
                                <Ionicons name="location-outline" size={18} color="gray" />
                                <Text>
                                    {theater.name} - Phòng: {room.name} ({room.type})
                                </Text>
                            </View>
                            <View style={{ flexDirection: 'row', gap: 2, marginTop: 10 }}>
                                <Ionicons name="time-outline" size={18} color="gray" />
                                <Text>
                                    Suất chiếu: {showTime.timeStart} - {moment(showTime.date).format('DD/MM/YYYY')}
                                </Text>
                            </View>
                        </View>
                    </View>

                    <View style={{ position: 'relative', marginTop: 20 }}>
                        <Image
                            source={require('~/assets/images/screen.svg')}
                            style={{ height: 30, width: WIDTH - 30, alignItems: 'center' }}
                            contentFit="contain"
                        />
                        <Text
                            style={{
                                // textAlign: 'center',
                                transform: [{ translateX: -25 }, { translateY: 0 }],
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                            }}
                        >
                            MÀN HÌNH
                        </Text>
                    </View>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        <View style={styles.table}>
                            {rows.map((row) => (
                                <View key={row} style={styles.row}>
                                    {seats
                                        .filter((seat) => seat.row === row)
                                        .map(
                                            (seat) =>
                                                !seat.isDelete && (
                                                    <TouchableWithoutFeedback
                                                        key={seat._id}
                                                        onPress={() =>
                                                            !selled.includes(seat._id) &&
                                                            !hold.includes(seat._id) &&
                                                            seat.status === true &&
                                                            (seat.type !== typeSeatEnum[2]
                                                                ? handleSelectSeat(seat)
                                                                : handleSelectSeatCouple(seat))
                                                        }
                                                    >
                                                        <View
                                                            style={[
                                                                styles.col,
                                                                seat.type === typeSeatEnum[0] && styles.standard,
                                                                seat.type === typeSeatEnum[1] && styles.vip,
                                                                seat.type === typeSeatEnum[2] && styles.couple,
                                                                !seat.status && styles.inaction,
                                                                selectSeat.find((item) => item === seat) &&
                                                                    styles.select,
                                                                (selled.includes(seat._id) ||
                                                                    hold.includes(seat._id)) &&
                                                                    styles.selled,
                                                                {
                                                                    marginBottom: seat.bottom * 20,
                                                                    marginLeft: seat.left * 22.5,
                                                                    marginRight: seat.right * 22.5,
                                                                },
                                                            ]}
                                                        >
                                                            <Text
                                                                style={[
                                                                    seat.type === typeSeatEnum[0] && styles.color1,
                                                                    seat.type === typeSeatEnum[1] && styles.color1,
                                                                    seat.type === typeSeatEnum[2] && styles.color2,
                                                                    !seat.status && styles.color3,
                                                                    selectSeat.find((item) => item === seat) &&
                                                                        styles.color2,
                                                                    (selled.includes(seat._id) ||
                                                                        hold.includes(seat._id)) &&
                                                                        styles.color3,
                                                                    { fontWeight: '500' },
                                                                ]}
                                                            >
                                                                {String.fromCharCode(64 + row)}
                                                                {seat.col}
                                                            </Text>
                                                        </View>
                                                    </TouchableWithoutFeedback>
                                                ),
                                        )}
                                </View>
                            ))}
                        </View>
                    </ScrollView>
                    <View
                        style={{
                            marginTop: 20,
                            flexDirection: 'row',
                            gap: 20,
                            flexWrap: 'wrap',
                            justifyContent: 'center',
                        }}
                    >
                        <View style={{ flexDirection: 'row' }}>
                            <View
                                style={[styles.standard, { height: 20, width: 20, borderRadius: 20, marginEnd: 5 }]}
                            ></View>
                            <Text style={{ fontWeight: '300' }}>Ghế thường</Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View
                                style={[styles.vip, { height: 20, width: 20, borderRadius: 20, marginEnd: 5 }]}
                            ></View>
                            <Text style={{ fontWeight: '300' }}>Ghế VIP</Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View
                                style={[styles.couple, { height: 20, width: 20, borderRadius: 20, marginEnd: 5 }]}
                            ></View>
                            <Text style={{ fontWeight: '300' }}>Ghế Couple</Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View
                                style={[styles.inaction, { height: 20, width: 20, borderRadius: 20, marginEnd: 5 }]}
                            ></View>
                            <Text style={{ fontWeight: '300' }}>Ghế đang bảo trì</Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View
                                style={[styles.selled, { height: 20, width: 20, borderRadius: 20, marginEnd: 5 }]}
                            ></View>
                            <Text style={{ fontWeight: '300' }}>Ghế đã mua</Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View
                                style={[styles.select, { height: 20, width: 20, borderRadius: 20, marginEnd: 5 }]}
                            ></View>
                            <Text style={{ fontWeight: '300' }}>Ghế chọn</Text>
                        </View>
                    </View>
                </View>
            </ScrollView>
            <View style={styles.payContant}>
                <View style={{ width: '60%' }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Text>{selectSeat.length} Ghế: </Text>
                        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
                            {selectSeat.map((seat, index) => (
                                <Text key={seat._id}>
                                    {String.fromCharCode(64 + seat.row)}
                                    {seat.col}
                                    {index < selectSeat.length - 1 && ', '}
                                </Text>
                            ))}
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 10 }}>
                        <Text style={{ marginEnd: 10 }}>Tổng cộng: </Text>
                        <Text style={{ color: '#3a2a62', fontWeight: '500' }}>
                            {priceSeat.toLocaleString('it-IT')} VNĐ
                        </Text>
                    </View>
                </View>
                <View style={{ margin: 10 }}>
                    <View style={styles.button}>
                        <Text style={{color: '#f3ea28'}}>Tiếp theo</Text>
                    </View>
                </View>
            </View>
        </>
    ) : (
        <Text>Loading...</Text>
    );
};

export default Seat;

const styles = StyleSheet.create({
    container: {
        // justifyContent: 'center',
        // alignItems: 'center',
        padding: 10,
        flex: 1,
    },
    row: {
        flexDirection: 'row',
        gap: 5,
    },
    col: {
        // padding: 4,
        height: 40,
        width: 40,
        borderRadius: 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    table: {
        gap: 5,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 30,
    },
    standard: {
        backgroundColor: '#b196f5',
    },
    vip: {
        backgroundColor: '#3a2a62',
    },
    couple: {
        backgroundColor: '#dc9bd2',
    },
    inaction: {
        backgroundColor: '#0f1b07',
    },
    select: {
        backgroundColor: '#f3ea28',
    },
    selled: {
        backgroundColor: '#48566a',
    },
    color1: {
        color: 'white',
    },
    color2: {
        color: '#663399',
    },
    color3: {
        color: 'rgb(167, 167, 167)',
    },
    containerInfo: {
        width: WIDTH - 20,
        // borderRadius: 10,
        flexDirection: 'row',
    },
    contentMain: {
        paddingVertical: 5,
        paddingHorizontal: 10,
        width: WIDTH - 120,
        // flex: 2,
    },
    payContant: {
        shadowOffset: { width: -2, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 3,
        backgroundColor: 'white',
        elevation: 5,
        padding: 10,
        position: 'absolute',
        bottom: 0,
        width: WIDTH - 20,
        marginHorizontal: 10,
        borderRadius: 5,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    button: {
        padding: 10,
        backgroundColor: '#3a2a62',
        borderRadius: 10,
    },
});
