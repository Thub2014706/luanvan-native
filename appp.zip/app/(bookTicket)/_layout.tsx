// import { NavigationContainer } from '@react-navigation/native';
import { Stack } from 'expo-router';
// import DetailFilm from './details/[id]';

export default function HomeLayout() {
    return (
        // <NavigationContainer>
            <Stack screenOptions={{ headerShown: false }}>
                {/* <Stack.Screen name="index" /> */}
                <Stack.Screen name="details/[id]" />
                <Stack.Screen name="seat/[showTime]" />
            </Stack>
        // </NavigationContainer>
    );
}
