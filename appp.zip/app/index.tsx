import { Redirect } from 'expo-router';

const StartPage = () => {
    return <Redirect href={'/'} />;
};

export default StartPage;
