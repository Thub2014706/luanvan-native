import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Login = () => {
  return (
    <View>
      <Text>login</Text>
    </View>
  )
}

export default Login

const styles = StyleSheet.create({})