// import DetailFilm from './details/[id]';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Stack } from 'expo-router';
import Account from '.';
import Login from './login';
// const Stack = createNativeStackNavigator();

export default function AccountLayout() {
    return (
        <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="index"  />
            <Stack.Screen name="login"  />
        </Stack>
    );
}
