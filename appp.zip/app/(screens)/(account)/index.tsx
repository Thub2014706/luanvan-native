import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
import { Link } from 'expo-router';

const Account = () => {
    return (
        <View style={styles.container}>
            <Link href={'/login'}>
                <Text>Đăng nhập</Text>
            </Link>
        </View>
    );
};

export default Account;

const styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
    },
});
